const emp = {
    create: '',
    fail: ''
}