# Employee-Manager
## A employee manager tool for companies
